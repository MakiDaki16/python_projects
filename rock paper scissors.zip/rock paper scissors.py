import random
print("Let's play Rock Paper Scissors! (only lowercase letters)")
score = 0
list1 = ["rock", "paper", "scissors"]

while True:
    me = random.choice(list1)

    you = input("\n\nWhat are you choosing? Rock, paper or scissors?\n")
    you = str(you)
    
    
    if me == you:
        print("\nTie!\nYou: ",you,"\nMe: ",me)
        print("Your score: ",score)


    if me == "rock" and you == "scissors" or me == "paper" and you == "rock" or me == "scissors" and you == "paper":
        print("\nYou lost! Try again. \nYou: ",you,"\nMe: ",me)
        print("Your score: ",score)

    if you == "rock" and me == "scissors" or you == "paper" and me == "rock" or you == "scissors" and me == "paper":
        print("\nCongratulations! You Won!\nYou: ",you,"\nMe: ",me)
        score = score + 1
        print("Your score: ",score)


        