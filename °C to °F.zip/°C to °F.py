from time import sleep



print("Welcome! This is a Fahrenheit to Celsius and Celcius to Fahrenheit calculator made by MakiDaki16")
while True:
    x = input("Press 1 to start the Fahrenheit to Celsius calculator \nPress 2 to start the Celsius to Fahrenheit calculator.\n")
    x = int(x)


    if x == 1:
        print("Starting Fahrenheit to Celsius calculator...")
        sleep(1.5)
        num1 = input("degrees Fahrenheit:")
        num1 = float(num1)
        res1 = (num1-32)*5/9
        res1 = float(res1)
        print("Celsius: ",res1)
        sleep(2.5)
       
    

    if x == 2:
        print("Starting Celsius to Fahrenheit calculator...")
        sleep(1.5)
        num2 = input("degrees Celsius:")
        num2 = float(num2)
        res2 = (num2*9/5)+32
        res2 = float(res2)
        print("Fahrenheit: ",res2)
        sleep(2.5)





